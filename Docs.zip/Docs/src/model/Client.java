package model;
import java.util.*;
  public class Client{
    
	 private final static double NORMAL = 0.0;
     private final static double SILVER = 0.015;
	 private final static double GOLD = 0.030;
	 private final static double PLATINUM = 0.05;
	 
	 
	 private String name;
	 private int registrationid;
	 private int valueofLoad;
	 private String type;
	 private Date date;
	 
	 public Client( String name, String type, int valueofLoad, int registrationid, Date date){
		 
		 
		 this.date = date;
		 this.type = type;
		 this.valueofLoad = valueofLoad;
		 this.name = name;
		 this.registrationid = registrationid;
		 
		 
	 }
	 
	 public int getId(){
		 
		 return registrationid;
		 
	 }
	 
	 public void setId(int registrationid){
		 
		 this.registrationid = registrationid;
		 
		 
	 }
	 
	 public void setType(String Type){
		 
		 this.type = type;
		 
		 
	 }
	 
	 public String getType(){
		 
		 
		 return type;
		 
	 }
	 
	 public String getName(){
		 
		 return name;
		 
	 }
	 
	 public void setName(String name){
		 
		 this.name = name;
		 
		 
	 }
	 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	 }
  
  
  
  
  
  
  
  
  
  
  
  
  
  }
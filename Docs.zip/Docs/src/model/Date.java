package model;
 public class Date{
	 
	 private String month;
	 private String day;
	 private String year;
	 
	 
	 public Date(String day, String month, String year){
		 
		 
		 this.day = day;
		 this.month = month;
		 this.year = year;
		 
		 
		 
	 }
	 
	 public void setMonth(String month){
		 
		this.month=month; 
		 
		 
		 
	 }
	 public String getMonth(){
		 
		return month; 
		 
	 }
	 
	 public void setDay(String day){
		 
		 this.day = day;
		 
		 
		 
	 }
	 
	 public String getDay(){
		 
		 return day;
		 
	 }
	 
	 public void setYear(String year){
		 
		 this.year = year;
		 
	 }
	 
	 public Strind getYear(){
		 
		 return year;
		 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
 }
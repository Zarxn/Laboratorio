package model;
import java.util.*;
 public class Load{
	 
	 private final static int PERISHABLE = 250000;
	 private final static int NOT_PERISHABLE = 80000;
	 private final static int DANGEROUS = 80000;
	 private int kgQuantity;
	 private int weightPerBox;
	 private int boxes;
	 private String typeofLoad;
	 private Client client;
	 
	 public Load( int boxes, int kgQuantity,  String typeofLoad, Client client, int weightPerBox){
		 
		 this.boxes = boxes;
		 this.kgQuantity = kgQuantity;
		 this.typeofLoad = typeofLoad;
		 this.client = client;
		 this.weightPerBox = weightPerBox;
		 
		 
		 
		 
	 }
	 public void setBoxes(int boxes){
		 
		 this.boxes = boxes;
		 
		 
	 }
	 public int getBoxes(){
		 
		 return boxes;
	 }
	 
	 public void setType( String typeofLoad){
		 
		 this.typeofLoad = typeofLoad;
		 
	 }
	 
	 public String getType(){
		 
		 return typeofLoad;
		 
	 }
	 
	 public void setKg( int kgQuantity){
		 
		 this.kgQuantity = (weightPerBox/1000) * boxes;
		 
	 }
	 
	public int getKg(){
		
		return kgQuantity;
	}
	
	public void setweightperBox( int weightPerBox){
		
	 this.weightPerBox = weightPerBox;	
		
	}
	public int getweightperBox(){
		
		return weightPerBox;
	}
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	  
 }


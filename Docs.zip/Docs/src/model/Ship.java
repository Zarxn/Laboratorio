package model;
import java.util.*;
public class Ship{

  private final static int MAX_CAPACIITY = 28000;
  private String shipname = "" , captain = "";
  private ArrayList<Client> client;
  private ArrayList<Load> load;
  
  
    
	public Ship(String shipname, String captain){
		
		this.shipname = shipname;
		this.captain = captain;
		client = new ArrayList<Client>();
		load = new ArrayList<Load>();
		
	}
   
   public void setShipname( String shipname){
	   
	   this.shipname = shipname;
	   
   }
   
   public String getShipname(){
	   
	 return shipname;  
	   
   }
   
   public void setCaptain( String captain){
	   
	   
	   this.captain = captain;
	   
   }
   
   public String getCaptain(){
	   
	   return captain;
	   
   }
   
	   
	   
	   
	   
   }
   
   public Client searchClient(int id){
	   
	   Client result = null;
	   for(int = 0; i<client.size(); i++){
		   
		   if(client.get(i).getId() == id){
			   
			   result = client.get(i);
			   
		   }
		   
		   
		   
	   }
	   
	   return result;
	   
   }
   
   public Load addLoad(int boxes, int kgQuantity, int typeofLoad){
	   
	   
	   Load newLoad = new Load(boxes, kgQuantity, typeofLoad);
	   load.add(newLoad);
	   
	   
	   
   }
   
   
	   
	   
   }
   
  
	  
	   
	   
	   
	   
	   
	   
   
    



























}
package ui;
import model.*;
import java.util.Scanner;


 public class Menu{
	 
	 
	 private final static int DETERMINATE_CLIENTS = 1;
	 private final static int LOAD_THE_SHIP = 2;
	 private final static int UPLOAD_THE_SHIP = 3;
	 private final static int DETERMINATE_SHIP_TOTAL_WEIGHT = 4;
	 private final static int UPGRADE_CLIENT = 5;
	 private final static int SET_SAIL= 6
	 
	 
	 public Date readDate(){
		 
		 System.out.print("ingrese el dia");
		 String day = sc.nextLine();
		 System.out.print("ingrese el mes");
		 String month = sc.nextLine();
		 System.out.print("ingrese el año");
		 String year = sc.nextLine();
		 
		 
		 return date;
		 
	 }
	 
	 public Client readClient(){
	 
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Por favor ingrese el nombre de la persona");
	  String name = sc.nextLine();
	  System.out.println("");
	  
	 System.out.println("Por favor ingrese que tipo de usuario es");
	 String type = sc.nextLine();
	  sc.nextLine();
	  System.out.println("");
	  
	   Date date = readDate();
	  
	  System.out.println("Por favor ingrese el numerode registro");
	  int registrationid = sc.nextInt();
	  sc.nextLine();
	  System.out.println("");
	  
	  System.out.println("Por favor ingrese la cantidad de cajas");
	  
	  int boxes = sc.nextInt();
	  
	   int valueofLoad = calculateValueofLoad();
	  
	  return new Client(name, type, valueofLoad, registrationid, date);
	  
	 }
	 
	  public Load readLoad(){
		  
		  Scanner sc = new Scanner(System.in);
		  System.out.println("Por favor ingrese la cantidad de cajas");
		  int boxes = sc.nextInt();
		  System.out.println("");
		  System.out.println("Por favor ingrese el peso de cada caja en gramos");
		  int weightPerBox = sc.nextInt();
		  sc.nextLine();
		  System.out.println("Por favor ingrese el tipo de carga");
		  String typeofLoad = sc.nextLine();
		  sc.nextLine();
		  System.out.println("Por favor digite al cliente al que correponde");
		  Client client = clients.get(sc.nextInt());
		  sc.nextLine();
		  int kgQuantity = getKg();
		  int contador = 0;
		  int contador2 = 0;
		  
		  for( int i = 0; i< loads.size(); i++){
			  
			  if(loads.get(i).gettypeofLoad().equalsIgnoreCase("perishable")){
				  
				  contador++;
				  
				  
				  
				  
			  } else if(loads.get(i).gettypeofLoad().equalsIgnoreCase("hazardous")){
				  
				  contador2++;
				  
				  
				  
			  }
			  
		      }
			  
			  if(contador >= 1 && typeofLoad.equalsIgnoreCase("hazardous")){
				  
				  
				  System.out.println("No se puede realizar la carga");
				  
			  } else if(contador2 >=1 && typeofLoad.equalsIgnoreCase("perishable")){
				  
				  System.out.println("No se pudo realizar la carga");
			  }
			  
			  if(kgQuantity > 28000){
				  
				  System.out.println("No se puede realizar la carga porque el peso excede el permitido");
				  
			  } else{
				  
				  
				  return new Load(boxes, kgQuantity, typeofLoad, client, weightPerBox);
				  
			  }
			  
		  }
		  public int readOption(){
			  
			  Scanner sc = new Scanner(System.in);
			  int option = sc.nextInt();
			  sc.nextLine();
			  
			  return option;
			  
		  }
		  
		  public void showMenu(){
			  
			  
			  System.out.println("Bienvenido a la aplicacion, por favor seleccione alguna de las siguientes opciones");
			  System.out.print("");
			  System.out.print("(1) Añadir clientes");
			  System.out.print("");
			  System.out.print("(2) Cargar el bargo");
			  System.out.print("");
			  System.out.print("(3) Descargar el barco");
			  System.out.print("");
			  System.out.print("(4) Mostrar el peso total del barco");
			  System.out.print("");
			  System.out.print("(5) Actualizar estatus del cliente ");
			  System.out.print("");
			  System.out.print("(6) Determinar si el barco puede o no zarpar");
			  
			  
			  
			  
			  
			  
			  
			  
			  
		  }
		  
		  public void doOperation(int option){
			  
			  int option = readOption();
			  switch(option){
				  
				  case DETERMINATE_CLIENTS:
				  
				  if(client.size() > 5){
					  
					  System.out.print("No se pueden agregar mas clientes, paso el limite");
					  
					  
				  } else{
					  
					  
					  
				  Client client = readClient();
				  client.addClient(client);
				  }
				  
				  break;
				  
				  case LOAD_THE_SHIP:
				  
				  Load load = readLoad();
				  load.addLoad(load);
				  
				  break;
				  
				  case UPLOAD_THE_SHIP:
				  
				  for(int i = 0; i< client.size(); i++){
					  
					  client.get(i) = null;
				  }
				  
				  for(int i = 0; i< load.size(); i++){
					  
					  load.get(i) = null;
					  
				  }
				  
				  System.out.print("El barco acaba de descargar exitosamente");
				  break;
				  
				  case DETERMINATE_SHIP_TOTAL_WEIGHT:
				  
				  for(int i = 0; i< loads.size(); i++){
					  
					  int totalWeight += loads.get(i).getKg();
					  
				  }
				   System.out.println(totalWeight);
				  
				  case UPGRADE_CLIENT:
				  
				  break;
				  
				  case SET_SAIL:
				   
				   int result = totalWeight;
				   int contador = 0;
				   
				   for(int i = 0; i<loads.size(); i++){
					   
					   
					   if(loads.get(i) = null){
						   
						   
					   } else{
						   
						  contador++ 
					   }
					   
					   
					   
				   }
				   
				  
				   if(contador >= 2 && result > 12000){
					   
					   System.out.println("El barco puede zarpar sin problemas");
					   
					   
				   } else{
					   
					  System.out.println("El barco no puede zarpar"); 
					   
				   }
				  
				  
				  
				  
				  
			  }
			  
			  
			  
			  
			  
			  
			  
		  }
		  
		  public void startProgram(){
			  
			  showMenu();
			  doOperation();
			  
			  
			  
			  
		  }
		  
		  
		  
		  
	  }
	 
	 
	 
	 
 
    
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 }